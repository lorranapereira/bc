<?php include_once('../html/cabecalho.html');?>

    <body id="page-top">
      <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
          <a class="navbar-brand" href="../index.html">Logo</a>
          
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Cadastro
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="filme.html">Filmes</a>
              <a class="dropdown-item active" href="ator.html">Atores</a>
              <a class="dropdown-item" href="categoria.html">Categorias</a>
            </div>
          </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Listas
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="../listas/filme.html">Filme</a>
                  <a class="dropdown-item" href="../listas/atores.html">Atores</a>
                  <a class="dropdown-item" href="../listas/categorias.html">Categorias</a>
                </div>
              </li>
        </ul>
        </div>
      
      </nav>
      <br/>
      <div class="container">
        <div id="content-wrapper">
  
          <div class="container-fluid">
  
            <?php 
              if($_GET["id"]){
                  include_once("../DAOs/ator.php");
                  include_once("../classes/ator.php");
                  $atorDAO = new AtorDAO();
                  $a = $atorDAO->buscar(intval($_GET["id"]));
                  $data = new DateTime($a->getDtnascimento());
                }

            ?>  
            <h1> <?php if($_GET["id"]){ echo " Alterar"; } else {echo "Cadastrar ";}?> Ator/Atriz</h1>
            </ol>  

            <form action="inserir/ator.php" method="post">
                  <div class="form-group col-md-6">
                    <label for="inputtext4">Nome Artístico</label>
                    <input type="text" value="<?php if($_GET["id"]){ echo $a->getNome(); }?>" name="nome_artistico" class="form-control" id="inputtext4">
                    <label for="inputtext4">Data de nascimento</label>
                    <input type="date"  name="dtnascimento" value="<?php if($_GET["id"]){ echo $a->getDtnascimento();}?>" class="form-control" id="inputtext4">
                    <label for="inputtext4">Nome</label>
                    <input type="text" value="<?php if($_GET["id"]){ echo $a->getNome_artistico(); }?>" name="nome" class="form-control" id="inputtext4">
                  <br/>
                  <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
                                
            </form>
            <br/>
            <br/>
            <br/>
            <br/>

      </div>
    </div>
  </div>

<?php include_once('../html/footer.html');?>
