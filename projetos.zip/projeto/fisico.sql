﻿CREATE TABLE Filme (
    id serial,
    titulo varchar(100) NOT NULL,
    classif_ind varchar(2),
    sinopse varchar(200),
    data_lancamento date,
    genero varchar(100) NOT NULL,
    FK_Categoria_id serial NOT NULL,
    CONSTRAINT filmepk PRIMARY KEY (id),
    CONSTRAINT  classif_ind_Check 
    CHECK ( classif_ind='L' OR classif_ind ='10' 
    OR classif_ind ='12' OR classif_ind='14' OR classif_ind ='16' OR classif_ind ='18'),
    CONSTRAINT "filmeFKcategoria" FOREIGN KEY (FK_Categoria_id)
      REFERENCES "categoria" (id)
      ON UPDATE CASCADE
      ON DELETE SET NULL
);

CREATE TABLE Ator (
    nome_artistico varchar(100) NOT NULL,
    id serial,
    nome varchar(100),
    datanascimento date,
    CONSTRAINT atorpk PRIMARY KEY (id)
);

CREATE TABLE Categoria (
    id serial,
    nome varchar(50) NOT NULL,
    CONSTRAINT Categoriapk PRIMARY KEY (id)
);

CREATE TABLE AtorFilme (
    idFilme integer,
    idAtor integer,
    CONSTRAINT "AtorFilmePK" PRIMARY KEY (idfilme, idator),
    CONSTRAINT "FKfilme" FOREIGN KEY (idFilme)
      REFERENCES "filme" (id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,
    CONSTRAINT "FKator" FOREIGN KEY (idAtor)
      REFERENCES "ator" (id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
);
