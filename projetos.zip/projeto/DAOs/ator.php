<?php 

class AtorDAO {
    private function CriaConexao()
    {
        $scon = "port=5432 host=localhost dbname=bdfilmes
        user=postgres ";
        $con = pg_connect($scon);
        if(!$con){
        echo "conexão com BD falhou!";
        pg_close($con);
        }
        return $con;
    }
    public function inserir($ator)
    {                
        $conn = $this->CriaConexao();
        $sql = 'INSERT INTO ator (nome,nome_artistico,datanascimento) VALUES ($1,$2,$3) RETURNING ID';
        $vetor = array($ator->getNome(),$ator->getNome_artistico(),$ator->getDtnascimento());
        $res = pg_query_params($conn,$sql, $vetor);
        $linha = pg_fetch_assoc($res);
        $ator->setId(intval($linha['id']));        
        pg_close($conn);
    }   
    public function deletar($id)
    {
        $conn = $this->CriaConexao();
        $sql = 'DELETE FROM ator WHERE id= $1';
        $res = pg_query_params($conn, $sql,array($id));     
        pg_close($conn);        
        
    }
    public function buscar($id)
    {
        include_once('../classes/ator.php');
        $conn = $this->CriaConexao();
        $sql = 'SELECT *FROM ator where id=$1';
        $res = pg_query_params($conn, $sql,array($id));
        $linha = pg_fetch_assoc($res);
        $c = new ator($linha['nome'],$linha['nome_artistico'],$linha['datanascimento']);
        $c->setId(intval($linha['id']));        
        pg_close($conn);
        return $c;
    }
    public function listar($limit,$offset)
    {
        include_once('../classes/ator.php');        
		$conn = $this->criaConexao();
		$sql = "SELECT * FROM ator LIMIT $1 OFFSET $2";
		$res = pg_query_params($conn, $sql, array($limit, $offset));
		$listaators = array();
		while($linha = pg_fetch_assoc($res)){
			$c = new ator($linha['nome'],$linha['nome_artistico'],$linha['datanascimento']);
			$c->setId(intval($linha['id']));
			
			array_push($listaators,$c);
		}
		pg_close($conn);
		return $listaators;
        
    }

    public function altera($ator)
    {
        $conn = $this->criaConexao();
		$sql="UPDATE ator SET nome = $1, descricao = $2, 
		  prioridade = $3 WHERE id = $4  ";
		$vet = array($ator->getNome());
		$res = pg_query_params($conn, $sql, $vet);
		
	}
 
}
?>
