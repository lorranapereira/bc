<?php

    include_once('../../DAOs/categoria.php');
    $adao = new CategoriaDAO();
    $id = intval($_GET['id']);
    $adao->deletar($id);
    header('Location:../categorias.php');

?>