<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap core CSS-->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    
  
      <!-- Custom fonts for this template-->
      <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
      <!-- Page level plugin CSS-->
      <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
       
    
    <title>SB Admin - Tables</title>


  </head>

  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand"  href="../index.html">Logo</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Cadastro
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="../cadastros/filme.html">Filmes</a>
            <a class="dropdown-item" href="../cadastros/ator.html">Atores</a>
            <a class="dropdown-item" href="../cadastros/categoria.html">Categorias</a>
          </div>
        </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Tabelas
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item active" href="../tabelas/filme.html">Filmes</a>
                <a class="dropdown-item" href="../tabelas/atores.html">Atores</a>
                <a class="dropdown-item" href="../tabelas/categorias.html">Categorias</a>
              </div>
            </li>
      </ul>
      </div>

    </nav>
    <br/>
    <div class="container">
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item active">
              Tabelas
            </li>
            <li class="breadcrumb-item">Filmes</li>
          </ol>

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Tabela Filmes           
              <a href="../cadastros/filme.html" class="btn btn-primary" style="position: relative; color:white; left:80%;"> Adicionar</a> 
              
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                        <th>Código</th>
                        <th>Título</th>
                        <th>Sinopse</th>
                        <th>Classificação indicativa</th>
                        <th>Gênero</th>
                        <th>Categoria</th>
                        <th>Lançamento</th> 
                        <th>Editar</th>
                        <th>Excluir</th>                        
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>01</td>
                        <td>Vingadores: Guerra Infinita</td>
                        <td>Thanos (Josh Brolin) enfim chega à Terra, disposto a reunir as Joias do Infinito. Para enfrentá-lo, os Vingadores precisam unir forças com os...</td>
                        <td>14</td>
                        <td>Aventura, Ação</td> 
                        <td>Filme</td>                                            
                        <td>26/04/2018</td>
                        <td><a href="../cadastros/filme.html"><span class="glyphicon glyphicon-pencil"></span></a>                        
                        </td>
                        <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                        </td>
                      </tr>
                      <tr>
                        <td>02</td>
                        <td>Batman - O Cavaleiro Das Trevas</td>
                        <td>Após dois anos desde o surgimento do Batman (Christian Bale), os criminosos de Gotham City têm muito o que temer. Com a ajuda do tenente James...</td>
                        <td>14</td>
                        <td>Aventura, Ação</td> 
                        <td>Filme</td>                                            
                        <td>26/04/2018</td>
                        <td><a href="../cadastros/filme.html"><span class="glyphicon glyphicon-pencil"></span></a>                        
                        </td>    
                        <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                        </td>                
                      </tr>
                      <tr>
                        <td>03</td>
                        <td>Matrix</td>
                        <td>Em um futuro próximo, Thomas Anderson (Keanu Reeves), um jovem programador de computador que mora em um cubículo escuro, é atormentado por...</td>
                        <td>14</td>
                        <td>Aventura, Ação</td> 
                        <td>Filme</td>                                            
                        <td>26/04/1999</td>
                        <td><a href="../cadastros/filme.html"><span class="glyphicon glyphicon-pencil"></span></a>                       
                        </td>
                        <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                        </td>
                      </tr>
                      <tr>
                        <td>04</td>
                        <td>Logan</td>
                        <td>Em 2029, Logan (Hugh Jackman) ganha a vida como chofer de limousine para cuidar do nonagenário Charles Xavier (Patrick Stewart). Debilitado...</td>
                        <td>14</td>
                        <td>Aventura, Ação</td> 
                        <td>Filme</td>                                            
                        <td>26/04/2017</td>
                        <td><a href="../cadastros/filme.html"><span class="glyphicon glyphicon-pencil"></span></a>                        
                        </td>
                        <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                        </td>
                      </tr>
  

                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
    
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer" style="width:100%;">
            <div class="container my-auto">
                <div class="copyright text-center my-auto" style="font-size:13px;">
                    <span>Sistema Administrador © Site de filmes 2018</span>
                </div>
            </div>
        </footer>    
        
        </div>


    <!-- /.content-wrapper -->

    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    
    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../vendor/chart.js/Chart.min.js"></script>>

  </body>

</html>
