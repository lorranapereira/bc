<?php
include_once('categoria.php');
class Filme{
    private $id;
    private $titulo;
    private $sinopse;
    private $classif_ind;
    private $genero;
    private $categoria;
    private $dtlacamento;
   
    public function __construct($titulo, $classif_ind, $sinopse=null, $genero=null, Categoria $categoria, $dtlacamento=null){
        $this->titulo = $titulo;
        $this->sinopse = $sinopse;
        $this->classif_ind = $classif_ind;
        $this->dtlacamento = $dtlacamento;  
        $this->genero = $genero;        
        $this->categoria = $gategoria;        
        $this->dtlacamento = $dtlacamento;        
        
    }
    public function getId(){
        return $this->id;
    }
    public function getTitulo(){
        return $this->titulo;
    }
    public function getSinopse(){
        return $this->sinopse;
    }
    public function getClassif_ind(){
        return $this->classif_ind;
    }
	public function getCategoria(){
		return $this->categoria;
    }
    public function getGenero(){
		return $this->genero;
    }
    public function getDtlancamento(){
		return $this->dtlancamento;
    }
    public function setId(int $id){
        $this->id = $id;
    }
    public function setTitulo(String $titulo){
        $this->titulo = $titulo;
    }
    public function setSinopse(String $sinopse){
        $this->sinopse = $sinopse;
    }
    public function setClassif_ind(String $classif_ind){
        if($classif_ind = 'L' OR $classif_ind = '10' OR $classif_ind = '12' OR $classif_ind = '14' OR $classif_ind = '16' OR $classif_ind = '18')
        $this->classif_ind = $classif_ind;
    }
    public function setGenero(String $genero){
            $this->genero = $genero;
    }
    public function setCategoria($categoria){
        $this->categoria = $categoria;
    }
    public function setDtlacamento(Date $dtlacamento){
        $this->dtlacamento = $dtlacamento;
    }
}
?>